package com.ps.repository;

import com.ps.domain.Course;

import java.util.List;

public interface CourseRepository {

    List<Course> findAll();
    void insert(Course course);
    void update(Course course);
    void delete(Course course);
    Course findById(String id);
}
