package com.ps.repository;

import com.ps.domain.Course;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class MySQLCourseRepoImpl implements CourseRepository {
    private static final Logger logger = LogManager.getLogger(MySQLCourseRepoImpl.class);

    @Override
    public List<Course> findAll() {
        logger.debug("about to get connection from DBConnectionManager");
        Connection connection = DBConnectionManager.getDBConnection();
        String sql = "select * from course";
        List<Course> courses = new ArrayList<>();
        try {
            logger.debug("sql: " + sql);
            PreparedStatement ps = connection.prepareStatement(sql);
            ps.execute();
            ResultSet rs = ps.getResultSet();
            Course course;
            String id, title, description, tags, category;
            int authorid;
            while (rs.next()) {
                id = rs.getString("id");
                title = rs.getString("title");
                description = rs.getString("description");
                category = rs.getString("category");
                tags = rs.getString("tags");
                authorid = rs.getInt("authorid");
                course = new Course(id, title, description, category, tags, authorid);
                courses.add(course);
            }
            System.out.println(courses);

        } catch (SQLException e) {
            logger.catching(e);
            logger.error("Error in displaying the course details");
            throw new RuntimeException("Error in displaying the course details");
        }
        return courses;
    }

    @Override
    public void insert(Course course) {
        logger.debug("about to get connection");
        Connection connection = DBConnectionManager.getDBConnection();
        String sql = "insert into course (id,title,description,category,tags,authorid) values (?,?,?,?,?,?)";
        try {
            logger.debug("sql: " + sql);
            PreparedStatement ps = connection.prepareStatement(sql);
            ps.setString(1, course.getId());
            ps.setString(2, course.getTitle());
            ps.setString(3, course.getDescription());
            ps.setString(4, course.getCategory());
            ps.setString(5, course.getTags());
            ps.setInt(6, course.getAuthorid());
            ps.executeUpdate();
        } catch (SQLException e) {
            logger.catching(e);
            logger.error("Error in inserting the course: " + course.getId());
            throw new RuntimeException("Error in inserting the course: " + course.getId());
        }

    }

    @Override
    public void update(Course course) {
        logger.debug("about to get the connection");
        Connection connection = DBConnectionManager.getDBConnection();
        String sql = "update course set title=? where id=?";
        try {
            logger.debug("sql: " + sql);
            PreparedStatement ps = connection.prepareStatement(sql);
            ps.setString(1, course.getTitle());
            ps.setString(2, course.getId());
            ps.executeUpdate();
        } catch (SQLException e) {
            logger.catching(e);
            logger.error("Error in updating the course: " + course.getId());
            throw new RuntimeException("Error in updating the course: " + course.getId());
        }
    }

    @Override
    public void delete(Course course) {
        logger.debug("about to get the connection from db");
        Connection connection = DBConnectionManager.getDBConnection();
        String sql = "delete from course where id=?";
        try {
            logger.debug("sql: " + sql);
            PreparedStatement ps = connection.prepareStatement(sql);
            ps.setString(1, course.getId());
            ps.executeUpdate();
        } catch (SQLException e) {
            logger.catching(e);
            logger.error("Error in deleting course: " + course.getId());
            throw new RuntimeException("Error in deleting course: " + course.getId());
        }
    }

    @Override
    public Course findById(String id) {
        logger.debug("about to fetch course from db: "+id);
        String sql = "Select * from course where id=?";
        Course course=null;
//        List<Course> courses = new ArrayList<>();
        try(Connection connection = DBConnectionManager.getDBConnection();
            PreparedStatement ps = connection.prepareStatement(sql)) {
            ps.setString(1,id);
            try(ResultSet rs = ps.executeQuery())
            {
                course = new Course();
                if(rs.next())
                {
                    course.setId(rs.getString("id"));
                    course.setTitle(rs.getString("title"));
                    course.setDescription(rs.getString("description"));
                    course.setCategory(rs.getString("category"));
                    course.setTags(rs.getString("tags"));
                    course.setAuthorid(rs.getInt("authorid"));
                }
            }
        } catch (SQLException e) {
            logger.error("Error getting a course by id: " + id);
            logger.catching(e);
            throw new RuntimeException("Error getting a course by id: " + id);
        }
        return course;
    }


}
