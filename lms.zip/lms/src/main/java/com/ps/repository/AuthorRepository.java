package com.ps.repository;

import com.ps.domain.Author;
import com.ps.domain.Course;

import java.util.List;

public interface AuthorRepository {

    List<Author> findall();
    void insert(Author author);
    void edit(Author author);
    void delete(Author author);
}
