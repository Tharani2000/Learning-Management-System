package com.ps.repository;

import com.ps.controller.CourseController;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.sql.DataSource;
import java.sql.Connection;
import java.sql.SQLException;

public class DBConnectionManager {

    private static final Logger logger = LogManager.getLogger(DBConnectionManager.class);

    static Connection getDBConnection() {
        logger.debug("in getDBConnection");
        Connection connection = null;
        try {
            InitialContext ic = new InitialContext();
            logger.debug("about to lookup jdbc");
            DataSource ds = (DataSource) ic.lookup("java:comp/env/jdbc/lms");
            logger.debug("dataSource: "+ ds);
            connection = ds.getConnection();
            logger.debug("got connection: "+ connection);
        } catch (NamingException e) {
            logger.error("naming exception getting jdbc connection");
            logger.error(e.getMessage());
            logger.catching(e);
        } catch (SQLException e) {
            logger.error("sql exception getting jdbc connection");
            logger.error(e.getMessage());
            logger.catching(e);
        }
        return connection;
    }
}
