package com.ps.repository;

import com.ps.domain.Author;
import com.ps.domain.User;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class MySQLUserRepoImpl implements UserRepository{
    private static final Logger logger = LogManager.getLogger(MySQLUserRepoImpl.class);
    @Override
    public List<User> findall() {
        logger.debug("get connection from DBConnectionManager");
        Connection connection = DBConnectionManager.getDBConnection();
        String sql = "select * from user";
        List<User> users = new ArrayList<>();
        try
        {
            logger.debug("sql: " + sql);
            PreparedStatement ps = connection.prepareStatement(sql);
            ps.execute();
            ResultSet rs = ps.getResultSet();
            User user;
            String id;
            String name;
            while (rs.next())
            {
                id=rs.getString("userid");
                name=rs.getString("name");
                user = new User(id,name);
                users.add(user);
            }
            System.out.println(users);
        } catch (SQLException e) {
            logger.catching(e);
            logger.error("Error in displaying the user details");
            throw new RuntimeException("Error in displaying the user details");
        }
        return users;
    }

    @Override
    public void insert(User user) {
        logger.debug("get connection");
        Connection connection = DBConnectionManager.getDBConnection();
        String sql = "insert into user (userid,name) values (?,?)";
        try {
            logger.debug("sql: " + sql);
            PreparedStatement ps = connection.prepareStatement(sql);
            ps.setString(1,user.getUserid());
            ps.setString(2, user.getName());

            ps.executeUpdate();
        } catch (SQLException e) {
            logger.catching(e);
            logger.error("Error in inserting the author details: " + user.getUserid());
            throw new RuntimeException("Error in inserting the author details: " + user.getUserid());
        }
    }

    @Override
    public void edit(User user) {
        logger.debug("get connection from DB");
        Connection connection = DBConnectionManager.getDBConnection();
        String sql = "update user set name=? where userid=?";
        try {
            logger.debug("sql: " + sql);
            PreparedStatement ps = connection.prepareStatement(sql);
            ps.setString(1, user.getName());
            ps.setString(2, user.getUserid());

            ps.executeUpdate();
        } catch (SQLException e) {
            logger.catching(e);
            logger.error("Error in updating the user details: " + user.getUserid());
            throw new RuntimeException("Error in updating the user details: " + user.getUserid());
        }
    }

    @Override
    public void delete(User user) {
        logger.debug("get connection from db");
        Connection connection = DBConnectionManager.getDBConnection();
        String sql="delete from user where userid=?";
        try {
            logger.debug("sql: " + sql);
            PreparedStatement ps = connection.prepareStatement(sql);
            ps.setString(1, user.getUserid());
            ps.executeUpdate();
        } catch (SQLException e) {
            logger.catching(e);
            logger.error("Error in deleting the user details: " + user.getUserid());
            throw new RuntimeException("Error in deleting user details: " + user.getUserid());
        }
    }
}
