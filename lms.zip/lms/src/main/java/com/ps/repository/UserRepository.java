package com.ps.repository;

import com.ps.domain.Author;
import com.ps.domain.User;

import java.util.List;

public interface UserRepository {
    List<User> findall();
    void insert(User user);
    void edit(User user);
    void delete(User user);
}
