package com.ps.repository;

import com.mysql.cj.jdbc.CallableStatementWrapper;
import com.ps.domain.Author;
import com.ps.domain.Course;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import javax.naming.NamingException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class MySQLAuthorRepoImpl implements AuthorRepository{
    private static final Logger logger = LogManager.getLogger(MySQLAuthorRepoImpl.class);
    @Override
    public List<Author> findall() {
        logger.debug("get connection from DBConnectionManager");
        Connection connection = DBConnectionManager.getDBConnection();
        String sql = "select * from author";
        List<Author> authors = new ArrayList<>();
        try
        {
            logger.debug("sql: " + sql);
            PreparedStatement ps = connection.prepareStatement(sql);
            ps.execute();
            ResultSet rs = ps.getResultSet();
            Author author;
            int id;
            String name;
            while (rs.next())
            {
                id=rs.getInt("id");
                name=rs.getString("name");
                author = new Author(id,name);
                authors.add(author);
            }
            System.out.println(authors);
        } catch (SQLException e) {
            logger.catching(e);
            logger.error("Error in displaying the author details");
            throw new RuntimeException("Error in displaying the author details");
        }
        return authors;
    }

    @Override
    public void insert(Author author) {
        logger.debug("get connection");
        Connection connection = DBConnectionManager.getDBConnection();
        String sql = "insert into author (id,name) values (?,?)";
        try {
            logger.debug("sql: " + sql);
            PreparedStatement ps = connection.prepareStatement(sql);
            ps.setInt(1, author.getId());
            ps.setString(2, author.getName());

            ps.executeUpdate();
        } catch (SQLException e) {
            logger.catching(e);
            logger.error("Error in inserting the author details: " + author.getId());
            throw new RuntimeException("Error in inserting the author details: " + author.getId());
        }


    }

    @Override
    public void edit(Author author) {
        logger.debug("get connection from DB");
        Connection connection = DBConnectionManager.getDBConnection();
        String sql = "update author set name=? where id=?";
        try {
            logger.debug("sql: " + sql);
            PreparedStatement ps = connection.prepareStatement(sql);
            ps.setString(1, author.getName());
            ps.setInt(2, author.getId());

            ps.executeUpdate();
        } catch (SQLException e) {
            logger.catching(e);
            logger.error("Error in updating the author details: " + author.getId());
            throw new RuntimeException("Error in updating the author details: " + author.getId());
        }

    }

    @Override
    public void delete(Author author) {
        logger.debug("get connection from db");
        Connection connection = DBConnectionManager.getDBConnection();
        String sql="delete from author where id=?";
        try {
            logger.debug("sql: " + sql);
            PreparedStatement ps = connection.prepareStatement(sql);
            ps.setInt(1,author.getId());
            ps.executeUpdate();
        } catch (SQLException e) {
            logger.catching(e);
            logger.error("Error in deleting the author details: " + author.getId());
            throw new RuntimeException("Error in deleting author details: " + author.getId());
        }
    }


}
