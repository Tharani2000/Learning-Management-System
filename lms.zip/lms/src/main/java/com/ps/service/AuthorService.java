package com.ps.service;

import com.ps.domain.Author;
import com.ps.domain.Course;
import com.ps.repository.AuthorRepository;
import com.ps.repository.MySQLAuthorRepoImpl;
import com.ps.repository.MySQLCourseRepoImpl;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import java.util.List;

public class AuthorService {
    private static final Logger logger = LogManager.getLogger(AuthorService.class);

    public List<Author> getAuthors() {
        logger.debug("about to call repo to get author");
        return new MySQLAuthorRepoImpl().findall();
    }

    public void insertAuthor(Author author)
    {
        logger.debug("Inserting the author");
        new MySQLAuthorRepoImpl().insert(author);
    }

   public void updateAuthor(Author author)
   {
       logger.debug("updating the author name");
       new MySQLAuthorRepoImpl().edit(author);
   }

   public void deletingAuthor(Author author)
   {
       logger.debug("Deleting the author name");
       new MySQLAuthorRepoImpl().delete(author);
   }
}
