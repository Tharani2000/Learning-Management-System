package com.ps.service;

import com.ps.domain.Course;
import com.ps.repository.MySQLCourseRepoImpl;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import java.util.List;

public class CourseService {
    private static final Logger logger = LogManager.getLogger(CourseService.class);

    public List<Course> getCourses() {
        logger.debug("about to call repo to get courses..");
        return new MySQLCourseRepoImpl().findAll();
    }

    public void insertCourse(Course course)
    {
        logger.debug("Inserting the course");
        new MySQLCourseRepoImpl().insert(course);
    }
    public void updateCourse(Course course)
    {
        logger.debug("Updating the course");
        new MySQLCourseRepoImpl().update(course);
    }
    public void delete(Course course)
    {
        logger.debug("Deleting the course: "+ course.getId());
        new MySQLCourseRepoImpl().delete(course);
    }

    public Course getCourseById(String id)
    {
        logger.info("about to get course by id: " + id);
        return new MySQLCourseRepoImpl().findById(id);
    }


}
