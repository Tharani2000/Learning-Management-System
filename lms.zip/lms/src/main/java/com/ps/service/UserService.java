package com.ps.service;

import com.ps.domain.Author;
import com.ps.domain.User;
import com.ps.repository.MySQLAuthorRepoImpl;
import com.ps.repository.MySQLUserRepoImpl;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import java.util.List;

public class UserService {
    private static final Logger logger = LogManager.getLogger(UserService.class);

    public List<User> getUsers() {
        logger.debug("about to call repo to get author");
        return new MySQLUserRepoImpl().findall();
    }
    public void insertUser(User user)
    {
        logger.debug("Inserting the user");
        new MySQLUserRepoImpl().insert(user);
    }

    public void updateUser(User user)
    {
        logger.debug("updating the user name");
        new MySQLUserRepoImpl().edit(user);
    }

    public void deleteUser(User user)
    {
        logger.debug("Deleting the user name");
        new MySQLUserRepoImpl().delete(user);
    }
}
