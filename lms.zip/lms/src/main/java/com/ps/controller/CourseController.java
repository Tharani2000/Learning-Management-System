package com.ps.controller;

import com.google.gson.Gson;
import com.ps.domain.Course;
import com.ps.service.CourseService;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.Reader;
import java.util.List;


@WebServlet(name = "courses", urlPatterns = {"/courses"})
public class CourseController extends HttpServlet {

    private static final Logger logger = LogManager.getLogger(CourseController.class);

        @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        logger.debug("got request from client");
        List<Course> courses = new CourseService().getCourses();
        String coursesJson = new Gson().toJson(courses);
        resp.setContentType("application/json");
        resp.getWriter().write(coursesJson);
        resp.getWriter().flush();
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        try{
            logger.info("got request from client to insert author");
            Reader reader = req.getReader();
            Course course = new Gson().fromJson(reader, Course.class);
            logger.info("about to call service passing: "+ course);
            new CourseService().insertCourse(course);
            logger.info("returning response back");
            resp.setStatus(200);
        }catch(Exception e){
            logger.error("Error in inserting course");
            logger.error(e.getMessage());
            logger.catching(e);
            resp.setStatus(500);
        }


    }

    @Override
    protected void doPut(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        try
        {
            logger.info("Got a request to update the course");
            Reader reader = req.getReader();
            Course course = new Gson().fromJson(reader,Course.class);
            logger.info("about to call service passing: "+course);
            new CourseService().updateCourse(course);
            logger.info("returning response back");
            resp.setStatus(200);
        }
        catch (Exception e)
        {
            logger.error("Error in updating the course");
            logger.error(e.getMessage());
            logger.catching(e);
            resp.setStatus(500);
        }
    }


    @Override
    protected void doDelete(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        try
        {
            logger.debug("Got a request to delete the course");
            Reader reader = req.getReader();
            Course course = new Gson().fromJson(reader,Course.class);
            logger.info("about to call service passing: "+course);
            new CourseService().delete(course);
            logger.info("returning response back");
            resp.setStatus(200);
        }catch (Exception e)
        {
            logger.error("Error in deleting the course");
            logger.error(e.getMessage());
            logger.catching(e);
            resp.setStatus(500);
        }
    }
}
