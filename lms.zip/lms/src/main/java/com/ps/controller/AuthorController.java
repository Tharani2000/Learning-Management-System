package com.ps.controller;

import com.google.gson.Gson;
import com.google.gson.JsonObject;
import com.google.gson.stream.JsonReader;
import com.ps.domain.Author;
import com.ps.domain.Course;
import com.ps.service.AuthorService;
import com.ps.service.CourseService;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import javax.json.Json;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.InputStream;
import java.io.Reader;
import java.util.List;

@WebServlet(name = "authors", urlPatterns = {"/authors"})
public class AuthorController extends HttpServlet {
    private static final Logger logger = LogManager.getLogger(AuthorController.class);

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        logger.debug("got request from client");
        List<Author> authors = new AuthorService().getAuthors();
        String authorsJson = new Gson().toJson(authors);
        resp.setContentType("application/json");
        resp.getWriter().write(authorsJson);
        resp.getWriter().flush();
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        try{
            logger.info("got request from client to insert course");
            Reader reader = req.getReader();
            Author author = new Gson().fromJson(reader, Author.class);
            logger.info("about to call service passing: "+ author);
            new AuthorService().insertAuthor(author);
            logger.info("returning response back");
            resp.setStatus(200);
        }catch(Exception e){
            logger.error("Error inserting course");
            logger.error(e.getMessage());
            logger.catching(e);
            resp.setStatus(500);
        }

    }

    @Override
    protected void doPut(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        try{
            logger.info("got request from client to update author");
            Reader reader = req.getReader();
            Author author = new Gson().fromJson(reader, Author.class);
            logger.info("about to call service passing: "+ author);
            new AuthorService().updateAuthor(author);
            logger.info("returning response back");
            resp.setStatus(200);
        }catch(Exception e){
            logger.error("Error in updating the name");
            logger.error(e.getMessage());
            logger.catching(e);
            resp.setStatus(500);
        }

    }

    @Override
    protected void doDelete(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        try
        {
            logger.info("got request from client to delete the author");
            Reader reader = req.getReader();
            Author author = new Gson().fromJson(reader,Author.class);
            logger.info("about to call service passing: "+author);
            new AuthorService().deletingAuthor(author);
            logger.info("returning response back");
            resp.setStatus(200);
        }catch (Exception e)
        {
            logger.error("Error in deleting the name");
            logger.error(e.getMessage());
            logger.catching(e);
            resp.setStatus(500);
        }
    }
}
