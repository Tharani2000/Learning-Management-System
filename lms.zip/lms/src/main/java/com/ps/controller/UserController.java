package com.ps.controller;

import com.google.gson.Gson;
import com.ps.domain.Author;
import com.ps.domain.User;
import com.ps.service.AuthorService;
import com.ps.service.UserService;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.Reader;
import java.util.List;

@WebServlet(name = "users",urlPatterns = {"/users"})
public class UserController extends HttpServlet {
    private static final Logger logger = LogManager.getLogger(UserController.class);

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        logger.debug("got request from client");
        List<User> users = new UserService().getUsers();
        String usersJson = new Gson().toJson(users);
        resp.setContentType("application/json");
        resp.getWriter().write(usersJson);
        resp.getWriter().flush();
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        try{
            logger.info("got request from client to insert user");
            Reader reader = req.getReader();
            User user = new Gson().fromJson(reader, User.class);
            logger.info("about to call service passing: "+ user);
            new UserService().insertUser(user);
            logger.info("returning response back");
            resp.setStatus(200);
        }catch(Exception e){
            logger.error("Error inserting user");
            logger.error(e.getMessage());
            logger.catching(e);
            resp.setStatus(500);
        }
    }

    @Override
    protected void doPut(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        try{
            logger.info("got request from client to update user");
            Reader reader = req.getReader();
            User user = new Gson().fromJson(reader, User.class);
            logger.info("about to call service passing: "+ user);
            new UserService().updateUser(user);
            logger.info("returning response back");
            resp.setStatus(200);
        }catch(Exception e){
            logger.error("Error in updating the name");
            logger.error(e.getMessage());
            logger.catching(e);
            resp.setStatus(500);
        }
    }

    @Override
    protected void doDelete(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        try
        {
            logger.info("got request from client to delete the user");
            Reader reader = req.getReader();
            User user = new Gson().fromJson(reader,User.class);
            logger.info("about to call service passing: "+user);
            new UserService().deleteUser(user);
            logger.info("returning response back");
            resp.setStatus(200);
        }catch (Exception e)
        {
            logger.error("Error in deleting the name");
            logger.error(e.getMessage());
            logger.catching(e);
            resp.setStatus(500);
        }
    }
}
