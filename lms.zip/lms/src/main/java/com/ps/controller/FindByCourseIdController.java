package com.ps.controller;

import com.google.gson.Gson;
import com.google.gson.stream.JsonReader;
import com.ps.domain.Course;
import com.ps.service.CourseService;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;


import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.List;

@WebServlet(name = "particularCourseDetail",urlPatterns = {"/particularCourseDetail"})
public class FindByCourseIdController extends HttpServlet {
    private static final Logger logger = LogManager.getLogger(FindByCourseIdController.class);

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        try {
            logger.debug("got request from client");
            JsonReader reader=new JsonReader(req.getReader());
            reader.beginObject();
            String id=(reader.nextName().equals("id"))?reader.nextString():null;
            reader.endObject();
            Course courses = new CourseService().getCourseById(id);
            String coursesJson = new Gson().toJson(courses);
            resp.setContentType("application/json");
            resp.getWriter().write(coursesJson);
            resp.getWriter().flush();
        }catch (Exception e){
            logger.error(e.getMessage());
            logger.catching(e);
        }
    }
}
